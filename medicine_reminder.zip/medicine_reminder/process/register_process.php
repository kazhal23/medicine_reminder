<?php
session_start();
include('../config/db.php');
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['register'])) {
    $name = htmlspecialchars(trim($_POST['name']));
    $email = htmlspecialchars(trim($_POST['email']));
    $password = htmlspecialchars(trim($_POST['password']));
    if (empty($name) || empty($email) || empty($password)) {
        $_SESSION['error'] = 'همه فیلدها الزامی هستند';
        header('Location: ../auth/register.php');
        exit;
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $_SESSION['error'] = 'ایمیل نامعتبر است';
        header('Location: ../auth/register.php');
        exit;
    }
    $check_email = $conn->prepare("SELECT * FROM users WHERE email = ?");
    $check_email->bind_param("s", $email);
    $check_email->execute();
    $result = $check_email->get_result();

    if ($result->num_rows > 0) {
        $_SESSION['error'] = 'این ایمیل قبلا ثبت شده است';
        header('Location: ../auth/register.php');
        exit;
    }
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
    $stmt = $conn->prepare("INSERT INTO users (name, email, password) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $name, $email, $hashed_password);
    if ($stmt->execute()) {
        $_SESSION['success'] = 'ثبت‌نام با موفقیت انجام شد. لطفا وارد شوید.';
        header('Location: ../auth/login.php');
        exit;
    } else {
        $_SESSION['error'] = 'خطایی رخ داد. دوباره تلاش کنید';
        header('Location: ../auth/register.php');
        exit;
    }
}
?>

