<?php
session_start();
include('../config/db.php');
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['login'])) {
    $email = htmlspecialchars(trim($_POST['email']));
    $password = htmlspecialchars(trim($_POST['password']));
    if (empty($email) || empty($password)) {
        $_SESSION['error'] = 'لطفا همه فیلدها را پر کنید';
        header('Location: ../auth/login.php');
        exit;
    }
    $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows == 1) {
        $user = $result->fetch_assoc();
        if (password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_name'] = $user['name'];
            header('Location: ../dashboard/index.php');
            exit;
        } else {
            $_SESSION['error'] = 'رمز عبور اشتباه است';
            header('Location: ../auth/login.php');
            exit;
        }
    } else {
        $_SESSION['error'] = 'ایمیل یافت نشد';
        header('Location: ../auth/login.php');
        exit;
    }
}
?>

