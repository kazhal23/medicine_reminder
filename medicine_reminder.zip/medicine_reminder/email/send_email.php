<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require 'vendor/autoload.php';
$mail = new PHPMailer(true);
try {
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = 'your_email@gmail.com';
    $mail->Password = 'your_app_password';
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port = 587;
    $mail->setFrom('your_email@gmail.com', 'Medicine Reminder');
    $mail->addAddress('receiver_email@example.com', 'User Name');
    $mail->isHTML(true);
    $mail->Subject = 'یادآوری مصرف دارو';
    $mail->Body    = 'سلام! این یک یادآوری برای مصرف داروی شماست. لطفاً در زمان مناسب آن را مصرف کنید.';
    $mail->send();
    echo 'ایمیل ارسال شد!';
} catch (Exception $e) {
    echo "خطا در ارسال ایمیل: {$mail->ErrorInfo}";
}
?>
