<?php
$host = '';
$user = '';
$password = '';
$database = '';

$conn = new mysqli($host, $user, $password, $database, $port);

if ($conn->connect_error) {
    die("اتصال ناموفق: " . $conn->connect_error);
}
?>

