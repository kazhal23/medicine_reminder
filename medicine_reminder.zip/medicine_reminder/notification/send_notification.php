<?php
session_start();
require '../config/db.php';
if (!isset($_SESSION['user_id'])) {
    header('Location: ../auth/login.php');
    exit;
}
$user_id = $_SESSION['user_id'];
$query = $conn->prepare("SELECT * FROM medicines WHERE user_id = ?");
$query->bind_param("i", $user_id);
$query->execute();
$result = $query->get_result();
while ($medicine = $result->fetch_assoc()) {
    $medicationName = $medicine['name'];
    $reminderTime = $medicine['reminder_time'];
    sendReminderEmail($_SESSION['user_email'], $medicationName, $reminderTime);
}

function sendReminderEmail($userEmail, $medicationName, $reminderTime) {
    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\Exception;
    require '../vendor/autoload.php';
    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';  
        $mail->SMTPAuth = true;
        $mail->Username = 'your-email@gmail.com';
        $mail->Password = 'your-email-password';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;
        $mail->setFrom('your-email@gmail.com', 'Reminder Service');
        $mail->addAddress($userEmail);
        $mail->isHTML(true);
        $mail->Subject = 'Reminder: Time to take your medication';
        $mail->Body    = 'Hello, this is a reminder to take your medication: ' . $medicationName . ' at ' . $reminderTime . '.';
        $mail->send();
        echo 'Reminder email has been sent.';
    } catch (Exception $e) {
        echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
    }
}
?>
