<?php
session_start();
include('../config/db.php');
if (!isset($_SESSION['reset_email'])) {
    header("Location: request_reset.php");
    exit;
}
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    if ($password !== $confirm_password) {
        die("❌ رمزها یکسان نیستند!");
    }

    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
    $user_id = $_SESSION['reset_user_id'];

    $stmt = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
    $stmt->bind_param("si", $hashed_password, $user_id);
    
    if ($stmt->execute()) {
        session_destroy();
        header("Location: ../auth/login.php?reset_success=1");
        exit;
    } else {
        die("❌ خطا در تغییر رمز!");
    }
}
?>
