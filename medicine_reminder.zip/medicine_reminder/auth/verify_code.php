<?php
session_start();
if (!isset($_SESSION['reset_email'])) {
    header("Location: request_reset.php");
    exit;
}
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $entered_code = trim($_POST['code']);

    if ($entered_code == $_SESSION['reset_code']) {
        header("Location: new_password.php");
        exit;
    } else {
        $error = "❌ کد اشتباه است!";
    }
}
?>
<!DOCTYPE html>
<html lang="fa">
<head>
    <meta charset="UTF-8">
    <title>تأیید کد بازیابی</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-4">
    <h2>🔢 تأیید کد بازیابی</h2>
    <?php if (isset($error)) echo "<div class='alert alert-danger'>$error</div>"; ?>
    <form method="POST">
        <div class="mb-3">
            <label>کد:</label>
            <input type="text" name="code" class="form-control" required>
        </div>
        <button type="submit" class="btn btn-success">✅ تأیید</button>
    </form>
</div>
</body>
</html>
