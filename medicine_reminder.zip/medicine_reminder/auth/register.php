<?php
session_start();
include('../config/db.php');
ini_set('display_errors', 1);
error_reporting(E_ALL);
$registration_message = '';
if (isset($_SESSION['user_id'])) {
    header('Location: ../dashboard/index.php');
    exit;
}
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['register'])) {
    $name = htmlspecialchars($_POST['name'], ENT_QUOTES, 'UTF-8');
    $email = htmlspecialchars($_POST['email'], ENT_QUOTES, 'UTF-8');
    $password = htmlspecialchars($_POST['password'], ENT_QUOTES, 'UTF-8');
    if (empty($name) || empty($email) || empty($password)) {
        $registration_message = "❌ لطفاً تمام فیلدها را پر کنید.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $registration_message = "❌ ایمیل نامعتبر است.";
    } else {
        $checkEmail = $conn->prepare("SELECT * FROM users WHERE email = ?");
        $checkEmail->bind_param("s", $email);
        $checkEmail->execute();
        $result = $checkEmail->get_result();
        if ($result->num_rows > 0) {
            $registration_message = "❌ این ایمیل قبلاً ثبت شده است.";
        } else {
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("INSERT INTO users (name, email, password) VALUES (?, ?, ?)");
            $stmt->bind_param("sss", $name, $email, $hashed_password);

            if ($stmt->execute()) {
                header('Location: login.php');
                exit;
            } else {
                $registration_message = "❌ خطا در ثبت‌نام. لطفاً دوباره تلاش کنید.";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fa">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ثبت‌نام</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
    <h2 class="text-center">ثبت‌نام</h2>
    <form method="POST" action="register.php">
        <div class="mb-3">
            <label for="name" class="form-label">نام:</label>
            <input type="text" name="name" class="form-control" required>
        </div>
        <div class="mb-3">
            <label for="email" class="form-label">ایمیل:</label>
            <input type="email" name="email" class="form-control" required>
        </div>
        <div class="mb-3">
            <label for="password" class="form-label">رمز عبور:</label>
            <input type="password" name="password" class="form-control" required>
        </div>
        <button type="submit" name="register" class="btn btn-success w-100">ثبت‌نام</button>
        <p class="text-center mt-3">
            قبلاً ثبت‌نام کرده‌اید؟ <a href="login.php">ورود</a>
        </p>
    </form>
    <p class="text-danger text-center mt-3">
        <?php echo $registration_message; ?>
    </p>
</div>
</body>
</html>
