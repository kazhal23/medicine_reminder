<?php
session_start();
include('../config/db.php');
require __DIR__ . '/../libs/PHPMailer/src/PHPMailer.php';
require __DIR__ . '/../libs/PHPMailer/src/SMTP.php';
require __DIR__ . '/../libs/PHPMailer/src/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

$error = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email = trim($_POST['email']);
    $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        $reset_code = rand(1000, 9999);
        $_SESSION['reset_email'] = $email;
        $_SESSION['reset_code'] = $reset_code;
        $mail = new PHPMailer(true);
        try {
            $mail->SMTPDebug = 2;
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'your-email@gmail.com';
            $mail->Password = 'your-app-password';
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port = 587;
            $mail->setFrom('your-email@gmail.com', 'Medicine Reminder');
            $mail->addAddress($email);
            $mail->isHTML(true);
            $mail->Subject = "کد بازیابی رمز عبور";
            $mail->Body = "<h2>کد بازیابی شما:</h2><h3 style='color:red;'>$reset_code</h3>";
            if ($mail->send()) {
                header("Location: verify_code.php");
                exit;
            } else {
                $error = "❌ خطا در ارسال ایمیل: " . $mail->ErrorInfo;
            }
        } catch (Exception $e) {
            $error = "❌ خطای SMTP: " . $mail->ErrorInfo;
        }
    } else {
        $error = "❌ ایمیل یافت نشد!";
    }
}
?>
<!DOCTYPE html>
<html lang="fa">
<head>
    <meta charset="UTF-8">
    <title>بازیابی رمز عبور</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-4">
    <h2>🔑 بازیابی رمز عبور</h2>
    <?php if (!empty($error)) echo "<div class='alert alert-danger'>$error</div>"; ?>
    <form method="POST">
        <div class="mb-3">
            <label>ایمیل:</label>
            <input type="email" name="email" class="form-control" required>
        </div>
        <button type="submit" class="btn btn-primary">📩 ارسال کد</button>
    </form>
</div>
</body>
</html>
