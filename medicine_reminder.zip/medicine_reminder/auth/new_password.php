<?php
session_start();
if (!isset($_SESSION['reset_email'])) {
    header("Location: request_reset.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="fa">
<head>
    <meta charset="UTF-8">
    <title>تنظیم رمز جدید</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-4">
    <h2>🔐 تنظیم رمز جدید</h2>
    <form action="process_reset.php" method="POST">
        <div class="mb-3">
            <label>رمز جدید:</label>
            <input type="password" name="password" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>تکرار رمز:</label>
            <input type="password" name="confirm_password" class="form-control" required>
        </div>
        <button type="submit" class="btn btn-primary">✅ ذخیره رمز جدید</button>
    </form>
</div>
</body>
</html>
