<?php
session_start();
include('../config/db.php');
if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit;
}
$success_message = "";
$error_message = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = htmlspecialchars($_POST['name']);
    $dosage = htmlspecialchars($_POST['dosage']);
    $instructions = htmlspecialchars($_POST['instructions']);
    $user_id = $_SESSION['user_id'];
    if (empty($name) || empty($dosage) || empty($instructions)) {
        $error_message = "❌ لطفاً تمام فیلدها را پر کنید!";
    } else {
        $sql = "INSERT INTO medicines (name, dosage, instructions, user_id) VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sssi", $name, $dosage, $instructions, $user_id);
        
        if ($stmt->execute()) {
            $success_message = "✅ دارو با موفقیت اضافه شد!";
        } else {
            $error_message = "❌ خطا در افزودن دارو!";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fa">
<head>
    <meta charset="UTF-8">
    <title>افزودن دارو</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-4">
        <h2>➕ افزودن دارو</h2>
        <a href="list_medicines.php" class="btn btn-secondary">🔙 بازگشت</a>
        <?php if ($success_message): ?><div class="alert alert-success"><?= $success_message ?></div><?php endif; ?>
        <?php if ($error_message): ?><div class="alert alert-danger"><?= $error_message ?></div><?php endif; ?>
        <form method="POST">
            <div class="mb-3">
                <label>نام دارو:</label>
                <input type="text" name="name" class="form-control">
            </div>
            <div class="mb-3">
                <label>دُز:</label>
                <input type="text" name="dosage" class="form-control">
            </div>
            <div class="mb-3">
                <label>دستور مصرف:</label>
                <textarea name="instructions" class="form-control"></textarea>
            </div>
            <button type="submit" class="btn btn-success">➕ ثبت دارو</button>
        </form>
    </div>
</body>
</html>
