<?php
session_start();
include('../config/db.php');
if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit;
}
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $sql = "DELETE FROM medicines WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        header("Location: list_medicines.php");
    } else {
        echo "❌ خطا در حذف دارو!";
    }
}
?>
