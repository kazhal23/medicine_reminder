<?php include('../includes/header.php'); ?>


<h2>👋 خوش آمدید، <?php echo $_SESSION['user_name']; ?>!</h2>
<p>در این بخش می‌توانید داروهای خود را مدیریت کنید.</p>

<?php include('../includes/footer.php'); ?>
